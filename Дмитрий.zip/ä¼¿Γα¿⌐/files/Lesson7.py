import tkinter as tk

def display_info():
    first_name = entry_first_name.get()
    last_name = entry_last_name.get()
    patronymic = entry_patronymic.get()
    info = f"Имя: {first_name}\nФамилия: {last_name}\nОтчество: {patronymic}"
    label_info.config(text=info)

# Создаем основное окно
root = tk.Tk()
root.title("Ввод данных")

# Создаем и размещаем виджеты для ввода имени
label_first_name = tk.Label(root, text="Введите ваше имя:")
label_first_name.pack()

entry_first_name = tk.Entry(root)
entry_first_name.pack()

# Создаем и размещаем виджеты для ввода фамилии
label_last_name = tk.Label(root, text="Введите вашу фамилию:")
label_last_name.pack()

entry_last_name = tk.Entry(root)
entry_last_name.pack()

# Создаем и размещаем виджеты для ввода отчества
label_patronymic = tk.Label(root, text="Введите ваше отчество:")
label_patronymic.pack()

entry_patronymic = tk.Entry(root)
entry_patronymic.pack()

# Создаем и размещаем кнопку для отображения данных
button_display = tk.Button(root, text="Показать данные", command=display_info)
button_display.pack()

# Создаем и размещаем виджет для отображения введенных данных
label_info = tk.Label(root, text="")
label_info.pack()

# Запускаем главный цикл
root.mainloop()