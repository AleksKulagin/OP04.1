def bank(a, years):
  for _ in range(years):
      a += a * 0.10  # Увеличиваем сумму на 10% каждый год
  return a

# Пример использования функции
initial_amount = float(input("Введите сумму вклада в рублях: "))
investment_years = int(input("Введите срок вклада в годах: "))

final_amount = bank(initial_amount, investment_years)
print(f"Сумма на счету после {investment_years} лет: {final_amount:.2f} рублей")